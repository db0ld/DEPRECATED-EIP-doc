TrueTypeFont: Grinched
Dennis Ludlow Productions 2000 all rights reserved
Sharkshock Productions

What up you Dr. Seuss fans. This font as well as all the others on my site are free 
for download for non-commercial  use only.
check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"